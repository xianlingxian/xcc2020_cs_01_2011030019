package com.example.demo108;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo108ApplicationTests {

    @Test
    void contextLoads() {
    }

}
